"""
Build fixed-length features: padding, masking, normalization.
"""

import numpy as np
import torch

def pad_tracks(tracks, max_tracks):
    """
    Pad N tracks to max_tracks using zero padding.
    """
    N, T, D = tracks.shape
    if N >= max_tracks:
        return tracks[:max_tracks], torch.ones(max_tracks).bool()

    pad = np.zeros((max_tracks - N, T, D))
    out = np.concatenate([tracks, pad], axis=0)
    mask = torch.zeros(max_tracks).bool()
    mask[:N] = True
    return out, mask
