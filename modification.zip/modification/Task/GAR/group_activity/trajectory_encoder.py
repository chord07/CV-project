"""
Trajectory encoder: LSTM over per-track features.
Each track = T x D → embedding vector g_i
"""

import torch
import torch.nn as nn

class TrajectoryEncoder(nn.Module):
    def __init__(self, in_dim=6, hidden=128, out_dim=128):
        super().__init__()
        self.lstm = nn.LSTM(in_dim, hidden, num_layers=2, batch_first=True)
        self.fc = nn.Linear(hidden, out_dim)

    def forward(self, x):
        """
        x: [N, T, D]
        """
        h, _ = self.lstm(x)
        # Take final time step
        g = h[:, -1]
        g = self.fc(g)
        return g
