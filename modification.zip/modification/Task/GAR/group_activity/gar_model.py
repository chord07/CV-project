"""
Full group activity recognition model:
- Tracklet encoder (per-person)
- GNN for interactions
- Classification head
"""

import torch
import torch.nn as nn
from trajectory_encoder import TrajectoryEncoder
from interaction_gnn import InteractionGNN

class GARModel(nn.Module):
    def __init__(self, num_classes, max_tracks=20):
        super().__init__()
        self.encoder = TrajectoryEncoder()
        self.gnn = InteractionGNN()
        self.fc = nn.Linear(128, num_classes)
        self.max_tracks = max_tracks

    def forward(self, tracks, mask):
        """
        tracks: [B, N, T, D]
        mask: [B, N]
        """
        B, N, T, D = tracks.shape
        logits = []
        for b in range(B):
            valid = mask[b]
            feats = tracks[b][valid]
            node_emb = self.encoder(feats)
            group_emb = self.gnn(node_emb)
            logit = self.fc(group_emb)
            logits.append(logit)
        logits = torch.stack(logits)
        return logits
