"""
Evaluation pipeline: compute Accuracy & F1.
"""

import torch
from torch.utils.data import DataLoader
from dataset_collective import CollectiveDataset
from feature_builder import pad_tracks
from gar_model import GARModel
from utils.metrics import accuracy, f1_score

def evaluate(config, model_path):
    ds = CollectiveDataset(
        config["annotation"],
        config["tracklet_dir"],
        window=config["window"]
    )
    loader = DataLoader(ds, batch_size=1, shuffle=False)

    model = GARModel(num_classes=config["num_classes"]).cuda()
    model.load_state_dict(torch.load(model_path))
    model.eval()

    preds, gts = [], []

    for tracks, label in loader:
        p, mask = pad_tracks(tracks[0].numpy(), config["max_tracks"])
        p = torch.tensor([p]).float().cuda()
        mask = torch.stack([mask]).cuda()

        with torch.no_grad():
            logit = model(p, mask)
            pred = torch.argmax(logit, dim=1).item()

        preds.append(pred)
        gts.append(label.item())

    print("Accuracy:", accuracy(preds, gts))
    print("F1:", f1_score(preds, gts))
