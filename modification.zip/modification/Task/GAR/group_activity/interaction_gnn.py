"""
Graph Attention Network for group interaction modeling.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl
from dgl.nn import GATConv

class InteractionGNN(nn.Module):
    def __init__(self, in_dim=128, hidden=128, out_dim=128, heads=4):
        super().__init__()
        self.g1 = GATConv(in_dim, hidden, heads)
        self.g2 = GATConv(hidden * heads, out_dim, 1)

    def build_graph(self, feats):
        """
        Build fully connected graph of N nodes.
        """
        N = feats.shape[0]
        src = []
        dst = []
        for i in range(N):
            for j in range(N):
                if i != j:
                    src.append(i)
                    dst.append(j)
        g = dgl.graph((src, dst))
        return g

    def forward(self, feats):
        g = self.build_graph(feats)
        h = F.relu(self.g1(g, feats))
        h = self.g2(g, h)
        group_feat = h.mean(dim=0)
        return group_feat
