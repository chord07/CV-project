"""
Training pipeline for GAR using MOTIP tracklets.
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from dataset_collective import CollectiveDataset
from feature_builder import pad_tracks
from gar_model import GARModel

def train(config):
    ds = CollectiveDataset(
        config["annotation"],
        config["tracklet_dir"],
        window=config["window"]
    )
    loader = DataLoader(ds, batch_size=config["batch"], shuffle=True)

    model = GARModel(num_classes=config["num_classes"]).cuda()
    opt = optim.Adam(model.parameters(), lr=config["lr"])
    ce = nn.CrossEntropyLoss()

    for epoch in range(config["epochs"]):
        for tracks, label in loader:
            B, N, T, D = tracks.shape
            padded, mask = [], []
            for b in range(B):
                p, m = pad_tracks(tracks[b].numpy(), config["max_tracks"])
                padded.append(p)
                mask.append(m)

            padded = torch.tensor(padded).float().cuda()
            mask = torch.stack(mask).cuda()
            label = label.cuda()

            logits = model(padded, mask)
            loss = ce(logits, label)

            opt.zero_grad()
            loss.backward()
            opt.step()

        print(f"Epoch {epoch} Loss = {loss.item():.3f}")
