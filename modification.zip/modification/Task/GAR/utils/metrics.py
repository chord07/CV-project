import numpy as np

def accuracy(preds, gts):
    preds = np.array(preds)
    gts = np.array(gts)
    return (preds == gts).mean()

def f1_score(preds, gts):
    from sklearn.metrics import f1_score
    return f1_score(gts, preds, average="macro")
