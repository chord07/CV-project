"""
Trajectory utilities: building tracklets, smoothing, computing velocity features.
"""

import numpy as np
from scipy.signal import savgol_filter

def smooth_track(track, window=7):
    """Apply Savitzky-Golay smoothing on bbox centers."""
    cx = savgol_filter(track[:, 2] + track[:, 4]/2, window, 2)
    cy = savgol_filter(track[:, 3] + track[:, 5]/2, window, 2)
    return cx, cy

def compute_velocity(cx, cy):
    """Compute per-frame velocity."""
    vx = np.gradient(cx)
    vy = np.gradient(cy)
    return vx, vy

def pack_tracklet(id, frames, bboxes):
    """Return a structured dict for one track."""
    arr = np.array(bboxes)  # Nx5: t,x,y,w,h
    cx, cy = smooth_track(arr)
    vx, vy = compute_velocity(cx, cy)

    return {
        "track_id": id,
        "frames": frames,
        "bboxes": arr,
        "center": np.stack([cx, cy], axis=1),
        "velocity": np.stack([vx, vy], axis=1)
    }
