"""
Convert MOTIP txt output → structured tracklet files (.npz)
"""

import os
import numpy as np
from collections import defaultdict
from trajectory_utils import pack_tracklet

def convert_txt_to_tracklets(txt_path, save_path):
    tracks = defaultdict(list)

    with open(txt_path) as f:
        for line in f.readlines():
            t, tid, x, y, w, h, *_ = line.strip().split(',')
            tracks[int(tid)].append((int(t), float(x), float(y), float(w), float(h)))

    tracklets = []
    for tid, arr in tracks.items():
        arr_sorted = sorted(arr, key=lambda x: x[0])
        frames = [a[0] for a in arr_sorted]
        bboxes = [a for a in arr_sorted]
        tracklets.append(pack_tracklet(tid, frames, bboxes))

    np.savez(save_path, tracklets=tracklets)
    print(f"Saved tracklets to {save_path}")
