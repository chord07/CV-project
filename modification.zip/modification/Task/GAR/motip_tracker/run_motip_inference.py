"""
Run MOTIP on a dataset and export trajectory results into MOT-style .txt files.
This script assumes MOTIP is already installed in your environment.
"""

import os
import torch
from models.motip import build as build_motip
from models.misc import load_checkpoint
from data.seq_dataset import SeqDataset
from torch.utils.data import DataLoader
from models.runtime_tracker import RuntimeTracker

@torch.no_grad()
def run_motip_on_video(config, video_root, output_txt):
    """
    Run MOTIP on one video directory.
    Args:
        config: MOTIP config dictionary.
        video_root: Path containing video frames.
        output_txt: Path to save MOT-style tracking results.
    """

    # Build MOTIP model
    model, _ = build_motip(config)
    load_checkpoint(model, path=config["INFERENCE_MODEL"])
    model.cuda().eval()

    # Load video sequence
    seq_ds = SeqDataset(
        seq_info={"name": "custom_video"},
        image_paths=sorted([os.path.join(video_root, f) for f in os.listdir(video_root)]),
        max_shorter=800,
        max_longer=1536,
        dtype=torch.float32
    )
    loader = DataLoader(seq_ds, batch_size=1, shuffle=False, num_workers=2)

    tracker = RuntimeTracker(
        model=model,
        sequence_hw=seq_ds.seq_hw(),
        use_sigmoid=False,
        assignment_protocol="hungarian",
        miss_tolerance=30,
        det_thresh=0.5,
        newborn_thresh=0.5,
        id_thresh=0.1,
    )

    results = []
    for t, (image, path) in enumerate(loader):
        image.tensors = image.tensors.cuda()
        image.mask = image.mask.cuda()
        tracker.update(image=image)

        out = tracker.get_track_results()
        for oid, score, cat, box in zip(out["id"], out["score"], out["category"], out["bbox"]):
            x, y, w, h = box.cpu().tolist()
            results.append(f"{t+1},{oid.item()},{x},{y},{w},{h},1,-1,-1,-1\n")

    # Save
    with open(output_txt, "w") as f:
        f.writelines(results)

    print(f"Saved MOTIP tracking results to {output_txt}")
