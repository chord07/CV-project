# models/motip_sot.py
# SOT-adapted MOTIP: IDDecoder for single-target presence + bbox regression.
# Author: adapted for user by ChatGPT
# All comments in English.

import torch
import torch.nn as nn
import torch.nn.functional as F


class IDDecoderSOT(nn.Module):
    """
    IDDecoder adapted for Single-Object Tracking (SOT).

    - Performs temporal self-attention over past track tokens + current query token.
    - Outputs:
        * presence_logit: scalar logit per query (sigmoid -> probability that this detection is the tracked target)
        * pred_box: predicted bbox regression [cx, cy, w, h] or [x,y,w,h] (match your DETR format)
        * embedding: current feature embedding after attention (for optional prototype consistency)
    """

    def __init__(self, d_model=256, nhead=8, num_layers=1, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.nhead = nhead
        self.dropout = dropout

        # Simple transformer-like self-attention block (single layer).
        self.self_attn = nn.MultiheadAttention(embed_dim=d_model, num_heads=nhead, dropout=dropout)

        # Small feed-forward after attention to mix features
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(d_model, d_model),
        )

        # Presence head: binary classification (is this the tracked target?)
        self.presence_head = nn.Linear(d_model, 1)

        # BBox regression head: predicts 4 numbers (format consistent with training/eval code)
        self.bbox_head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(inplace=True),
            nn.Linear(d_model, 4)
        )

        # Optional prototype vector (EMA updated) for the tracked target
        self.register_buffer("target_prototype", torch.zeros(d_model), persistent=True)

    def forward(self, track_tokens, current_token, attn_mask=None):
        """
        Args:
            track_tokens: Tensor of shape (T, B, C) representing historical track tokens
            current_token: Tensor of shape (1, B, C) representing current detection/query embedding
            attn_mask: optional attention mask for self-attention
        Returns:
            dict with keys: 'logit' (B,), 'bbox' (B,4), 'embedding' (B,C)
        """
        # Concatenate temporal sequence: history then current
        seq = torch.cat([track_tokens, current_token], dim=0)  # (T+1, B, C)

        # Self-attention expects (L, N, E)
        attn_out, _ = self.self_attn(seq, seq, seq, attn_mask=attn_mask)  # (L, B, C)
        # Residual + FFN
        seq2 = seq + attn_out
        seq2 = seq2 + self.ffn(seq2)

        # Current frame representation: last element of seq2
        cur_feat = seq2[-1]  # (B, C)

        # Presence logit and bbox regression
        presence_logit = self.presence_head(cur_feat).squeeze(-1)  # (B,)
        pred_box = self.bbox_head(cur_feat)  # (B,4)

        return {"logit": presence_logit, "bbox": pred_box, "embedding": cur_feat}

    def update_target_prototype(self, embedding, momentum=0.9):
        """
        Update stored prototype with exponential moving average.
        Args:
            embedding: Tensor (B, C) -> we take batch mean
            momentum: EMA momentum
        """
        if embedding is None:
            return
        with torch.no_grad():
            batch_mean = embedding.detach().mean(dim=0)
            self.target_prototype = momentum * self.target_prototype + (1.0 - momentum) * batch_mean


class MOTIPSOTModel(nn.Module):
    """
    High-level wrapper for a SOT model based on MOTIP ideas.

    Responsibilities:
    - Accept video frames batches and (optionally) initial bbox to build prototype.
    - Use a backbone + DETR-like module to produce per-frame embeddings (projected to d_model).
    - Maintain a small tracklet buffer of previous embeddings for temporal attention.

    Integration notes:
    - The 'detr' should provide an object-level embedding for the tracked target.
      If your DETR returns a sequence of hs (num_decoder_layers x B x C), we pick the last layer.
    - If your detection network outputs multiple detections, you must select the detection corresponding
      to the tracked target (via IoU with init bbox) during initialization.
    """

    def __init__(self, backbone, detr, d_model=256, track_length=8, freeze_backbone=False):
        super().__init__()
        self.backbone = backbone
        self.detr = detr
        self.d_model = d_model
        self.track_length = track_length

        self.decoder = IDDecoderSOT(d_model=d_model)
        self.proj = nn.Identity()  # optional projection if detector output != d_model

        # allowed: freeze backbone/detr to speed up training
        if freeze_backbone:
            for p in self.backbone.parameters():
                p.requires_grad = False
            for p in self.detr.parameters():
                p.requires_grad = False

    def forward_once(self, image_tensor):
        """
        Run backbone + detector on a single image tensor.
        Args:
            image_tensor: Tensor shape (B,3,H,W)
        Returns:
            current_embedding: Tensor (B, C) - the detector-query feature for the target.
            det_boxes: list/ tensor of candidate boxes if available (optional)
        """
        # NOTE: Replace the following lines with your backbone + DETR forward API.
        # Expectation: detr returns (hs, refs) where hs[-1] is (num_queries, B, C) or (B, C)
        # For this prototype, we call backbone -> detr(features) and take hs[-1] (if exists).
        features = self.backbone(image_tensor)  # user-supplied backbone
        # detr_out should be compatible with your DETR implementation.
        # For Deformable DETR style: hs (L, bs, num_queries, C) or (L, bs, C) depending on wrapper.
        detr_out = self.detr(features)
        # The wrapper here must be matched to your DETR output format.
        # Example: if detr returns hs (L, B, C) -> take hs[-1]
        if isinstance(detr_out, tuple) or isinstance(detr_out, list):
            hs = detr_out[0]
            # if hs shape is (L, B, num_queries, C), you may need to select appropriate query
            # We assume hs is (L, B, C) or (L, B, num_queries, C) with num_queries==1 for target embedding
            if hs.dim() == 4:
                # pick first query by default; if your detector has many queries, adapt selection
                cur = hs[-1, :, 0, :]  # (B, C)
            else:
                cur = hs[-1]  # (B, C)
        else:
            # If detr returns a single tensor
            hs = detr_out
            if hs.dim() == 3:
                cur = hs[-1]  # (B, C)
            elif hs.dim() == 2:
                cur = hs  # (B, C)
            else:
                raise RuntimeError("Unexpected detr output shape: %s" % (str(hs.shape),))
        # final projection if necessary
        cur_feat = self.proj(cur)  # (B, C)
        return cur_feat

    def forward(self, image_sequence, init_embedding=None):
        """
        Process a short image_sequence (list or tensor of frames) and produce SOT outputs.
        Args:
            image_sequence: Tensor (T, B, 3, H, W)
            init_embedding: optional initial embedding (1, B, C) used as the prototype / first token
        Returns:
            outputs: list of dicts per frame {logit, bbox, embedding}
        """
        device = image_sequence.device if isinstance(image_sequence, torch.Tensor) else None
        T = image_sequence.shape[0]
        B = image_sequence.shape[1]

        # maintain a small buffer of historical tokens; if no init provided, we use zeros
        if init_embedding is None:
            track_tokens = torch.zeros((self.track_length, B, self.d_model), device=image_sequence.device)
        else:
            # fill buffer with initial embedding repeated
            init = init_embedding.squeeze(0)  # (B, C)
            track_tokens = init.unsqueeze(0).repeat(self.track_length, 1, 1)  # (L, B, C)

        outputs = []
        for t in range(T):
            img = image_sequence[t]  # (B,3,H,W)
            cur_feat = self.forward_once(img)  # (B, C)
            cur_token = cur_feat.unsqueeze(0)  # (1, B, C)

            out = self.decoder(track_tokens, cur_token)
            outputs.append(out)

            # update track buffer: push current embedding, pop oldest
            track_tokens = torch.cat([track_tokens[1:], cur_token], dim=0)

            # update prototype in decoder for optional consistency
            self.decoder.update_target_prototype(out["embedding"])

        return outputs
