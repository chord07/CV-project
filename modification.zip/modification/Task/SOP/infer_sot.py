# infer_sot.py
# Run single-object tracking inference on a directory of frames or a video file.
# Example usage:
# python infer_sot.py --video_path ./videos/seq1.mp4 --init_bbox 100,200,60,80 --out_dir ./results

import argparse
import os
import torch
import cv2
import numpy as np
from PIL import Image
import torchvision.transforms as T
from models.motip_sot import MOTIPSOTModel

def parse_bbox(s):
    parts = s.split(",")
    return [float(x) for x in parts]

def load_video_frames(video_path):
    cap = cv2.VideoCapture(video_path)
    frames = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frames.append(Image.fromarray(rgb))
    cap.release()
    return frames

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video_path", type=str, required=True)
    parser.add_argument("--init_bbox", type=str, required=True, help="x,y,w,h for first frame target")
    parser.add_argument("--out_dir", type=str, default="./sot_results")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # TODO: plug in actual backbone & detr implementation from your codebase
    backbone = lambda x: x
    detr = lambda x: x
    model = MOTIPSOTModel(backbone=backbone, detr=detr, d_model=256, track_length=8).to(device)
    model.eval()

    frames = load_video_frames(args.video_path)
    transform = T.Compose([T.Resize((800, 1333)), T.ToTensor()])

    imgs = []
    for img in frames:
        imgs.append(transform(img))
    imgs = torch.stack(imgs, dim=0)  # (T, C, H, W)
    imgs = imgs.unsqueeze(1).to(device)  # add batch dim -> (T, B, C, H, W)

    init_bbox = torch.tensor(parse_bbox(args.init_bbox), dtype=torch.float32).unsqueeze(0).to(device)  # (1,4)

    # For initialization, we may want to compute an initial embedding by running first frame through detector
    with torch.no_grad():
        # create an initial embedding by running forward_once on first image
        first_frame = imgs[0]
        # forward_once expects (B,3,H,W)
        init_emb = model.forward_once(first_frame)  # (B, C)
        init_emb = init_emb.unsqueeze(0)  # (1, B, C)

        outputs = model(imgs, init_embedding=init_emb)

    # Save predictions (convert predicted boxes to xywh)
    os.makedirs(args.out_dir, exist_ok=True)
    pred_boxes = []
    pred_scores = []
    for out in outputs:
        box = out["bbox"].detach().cpu().numpy()[0]  # (4,)
        score = torch.sigmoid(out["logit"]).item()
        pred_boxes.append(box.tolist())
        pred_scores.append(score)

    # Save txt results
    with open(os.path.join(args.out_dir, "result.txt"), "w") as f:
        for t, (b, s) in enumerate(zip(pred_boxes, pred_scores), start=1):
            f.write(f"{t},{b[0]},{b[1]},{b[2]},{b[3]},{s:.4f}\n")

    print("Inference completed. Results saved to", args.out_dir)


if __name__ == "__main__":
    main()
