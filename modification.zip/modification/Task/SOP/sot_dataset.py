# data/sot_dataset.py
# Dataset and sampler utilities to create single-object tracking training samples
# from LaSOT / GOT-10k / TrackingNet style annotations.
# The dataset yields tuples: (image_sequence_tensor, init_bbox_tensor, gt_boxes_sequence)

import os
import random
from typing import List, Tuple
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as T
import numpy as np
from utils.box import xywh_to_xyxy, xyxy_to_xywh


class SOTSequenceDataset(Dataset):
    """
    Dataset that provides short clips for single-object tracking training.

    Directory layout expected (per sequence):
        root/
            seq_0001/
                img/000001.jpg
                img/000002.jpg
                ...
                gt.txt   # each line: frame_idx, id, x, y, w, h, ...
    This loader reads sequences and produces training windows of length window_size:
        - You specify window_size (T)
        - Each sample returns (images_tensor, init_bbox, gt_boxes_tensor)
    """

    def __init__(self, root: str, split: str = "train", window_size: int = 8, transform=None, min_track_len=16):
        """
        Args:
            root: dataset root containing sequences
            split: unused for generic loader, retained for API compatibility
            window_size: number of frames in each sample (including initial frame)
            transform: torchvision transforms applied per image
            min_track_len: ignore sequences shorter than this
        """
        self.root = root
        self.window_size = window_size
        self.transform = transform if transform is not None else T.Compose([
            T.Resize((800, 1333)),
            T.ToTensor(),
        ])
        self.seq_infos = self._collect_sequences(min_track_len)

    def _collect_sequences(self, min_track_len):
        seqs = []
        for seq_name in sorted(os.listdir(self.root)):
            seq_dir = os.path.join(self.root, seq_name)
            img_dir = os.path.join(seq_dir, "img")
            gt_path = os.path.join(seq_dir, "gt", "gt.txt")
            if not os.path.isdir(seq_dir) or not os.path.exists(img_dir) or not os.path.exists(gt_path):
                continue
            frames = sorted(os.listdir(img_dir))
            if len(frames) < min_track_len:
                continue
            seqs.append({
                "name": seq_name,
                "img_dir": img_dir,
                "gt": gt_path,
                "num_frames": len(frames),
            })
        return seqs

    def __len__(self):
        # approximate number of windows across sequences
        total = 0
        for s in self.seq_infos:
            total += max(0, s["num_frames"] - self.window_size + 1)
        return total

    def _load_gt_for_seq(self, gt_path):
        """
        Parse gt.txt into dict: frame_index (1-based) -> list of boxes (x,y,w,h,id)
        Expecting MOT-like gt format.
        """
        frame_dict = {}
        with open(gt_path, "r") as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) < 6:
                    continue
                frame = int(parts[0])
                tid = int(parts[1])
                x, y, w, h = float(parts[2]), float(parts[3]), float(parts[4]), float(parts[5])
                frame_dict.setdefault(frame, []).append({
                    "id": tid,
                    "bbox": [x, y, w, h]
                })
        return frame_dict

    def __getitem__(self, idx):
        """
        Randomized sampling: map idx to a sequence and start frame.
        Returns:
            images: Tensor (T, 3, H, W)
            init_bbox: Tensor (4,) in xywh
            gt_boxes: Tensor (T, 4) in xywh (for the tracked object)
            is_valid: bool mask indicates object presence per frame
        """
        # map idx to a particular sequence and start offset:
        seq_id = 0
        acc = 0
        for s in self.seq_infos:
            cnt = max(0, s["num_frames"] - self.window_size + 1)
            if idx < acc + cnt:
                seq = s
                offset = idx - acc
                break
            acc += cnt
            seq_id += 1
        else:
            # fallback: last sequence, random offset
            seq = self.seq_infos[-1]
            offset = random.randint(0, seq["num_frames"] - self.window_size)

        frame_dict = self._load_gt_for_seq(seq["gt"])
        img_files = sorted(os.listdir(seq["img_dir"]))
        start = offset + 1  # 1-based frame index in gt format
        end = start + self.window_size - 1

        # choose a target id that appears in the full window if possible
        candidate_ids = set()
        for fid in range(start, end + 1):
            for obj in frame_dict.get(fid, []):
                candidate_ids.add(obj["id"])
        if not candidate_ids:
            # no object in this window - return zeros (rare)
            images = []
            for fidx in range(start, end + 1):
                p = os.path.join(seq["img_dir"], img_files[fidx - 1])
                img = Image.open(p).convert("RGB")
                images.append(self.transform(img))
            images = torch.stack(images, dim=0)
            init_bbox = torch.zeros(4)
            gt_boxes = torch.zeros((self.window_size, 4))
            is_valid = torch.zeros(self.window_size).bool()
            return images, init_bbox, gt_boxes, is_valid

        target_id = random.choice(list(candidate_ids))

        images = []
        gt_boxes = []
        is_valid = []
        for fidx in range(start, end + 1):
            p = os.path.join(seq["img_dir"], img_files[fidx - 1])
            img = Image.open(p).convert("RGB")
            images.append(self.transform(img))
            objs = frame_dict.get(fidx, [])
            found = False
            for obj in objs:
                if obj["id"] == target_id:
                    gt_boxes.append(torch.tensor(obj["bbox"], dtype=torch.float32))
                    found = True
                    break
            if not found:
                gt_boxes.append(torch.tensor([0, 0, 0, 0], dtype=torch.float32))
            is_valid.append(found)

        images = torch.stack(images, dim=0)  # (T, 3, H, W)
        gt_boxes = torch.stack(gt_boxes, dim=0)  # (T,4)
        is_valid = torch.tensor(is_valid, dtype=torch.bool)

        # initial bbox = bbox at frame 0 (start)
        init_bbox = gt_boxes[0].clone()

        return images, init_bbox, gt_boxes, is_valid
