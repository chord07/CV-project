# train_sot.py
# Training script for SOT variant using MOTIP ideas.
# This is a minimal, single-node training loop with checkpointing.

import os
import time
import argparse
import torch
from torch.utils.data import DataLoader
from torch.optim import AdamW
from data.sot_dataset import SOTSequenceDataset
from models.motip_sot import MOTIPSOTModel, compute_sot_loss if False else None
from utils.box import xywh_to_xyxy
import torch.nn.functional as F

# NOTE: compute_sot_loss is provided inline below for clarity (simple BCE + L1 + optional prototype MSE).


def compute_sot_loss(output, gt_box, is_target_mask, prototype=None, weights=None):
    """
    output: dict with 'logit' (B,), 'bbox' (B,4), 'embedding' (B,C)
    gt_box: Tensor (B,4) - ground truth boxes for this frame
    is_target_mask: Tensor (B,) bool - whether the target exists this frame
    """
    if weights is None:
        weights = {"cls": 1.0, "l1": 5.0, "giou": 2.0, "cons": 0.5}

    # binary classification loss
    cls_loss = F.binary_cross_entropy_with_logits(output["logit"], is_target_mask.float())

    # bbox L1 loss only on frames where target exists
    if is_target_mask.any():
        l1 = F.l1_loss(output["bbox"][is_target_mask], gt_box[is_target_mask], reduction="mean")
    else:
        l1 = torch.tensor(0.0, device=output["bbox"].device)

    # prototype consistency
    cons_loss = torch.tensor(0.0, device=output["bbox"].device)
    if prototype is not None:
        cons_loss = F.mse_loss(output["embedding"], prototype.unsqueeze(0).expand_as(output["embedding"]))

    total = weights["cls"] * cls_loss + weights["l1"] * l1 + weights["cons"] * cons_loss
    return total, {"cls": cls_loss.item(), "l1": l1.item(), "cons": cons_loss.item()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=str, required=True, help="Root folder containing sequences")
    parser.add_argument("--out-dir", type=str, default="./checkpoints")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--window", type=int, default=8)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--freeze-backbone", action="store_true")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    dataset = SOTSequenceDataset(root=args.data_root, window_size=args.window)
    loader = DataLoader(dataset, batch_size=args.batch, shuffle=True, num_workers=4, drop_last=True)

    # TODO: replace these placeholders with actual backbone & DETR objects from your codebase
    backbone = lambda x: x  # placeholder - REPLACE
    detr = lambda x: x  # placeholder - REPLACE

    model = MOTIPSOTModel(backbone=backbone, detr=detr, d_model=256, track_length=args.window, freeze_backbone=args.freeze_backbone)
    model.to(device)

    optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr, weight_decay=1e-4)

    os.makedirs(args.out_dir, exist_ok=True)

    for epoch in range(args.epochs):
        model.train()
        epoch_loss = 0.0
        t0 = time.time()
        for step, (imgs, init_bbox, gt_boxes, is_valid) in enumerate(loader):
            # imgs: (T, B, 3, H, W) in our dataset, but DataLoader returns single sample, adjust accordingly.
            # The dataset currently returns (T, C, H, W); add batch dim
            T, C, H, W = imgs.shape
            imgs = imgs.to(device)  # (T, C, H, W)
            imgs = imgs.unsqueeze(1)  # add B=1 -> (T, B, C, H, W)
            init_bbox = init_bbox.to(device).unsqueeze(0)  # (B,4)
            gt_boxes = gt_boxes.to(device)
            is_valid = is_valid.to(device)

            optimizer.zero_grad()

            # Run model forward: expects (T, B, 3, H, W)
            outputs = model(imgs, init_embedding=None)

            # We compute loss per frame and sum/average
            total_loss = 0.0
            metrics_acc = {"cls": 0.0, "l1": 0.0, "cons": 0.0}
            prototype = model.decoder.target_prototype if hasattr(model.decoder, "target_prototype") else None

            for t in range(len(outputs)):
                out = outputs[t]
                gt_box_t = gt_boxes[t].unsqueeze(0)  # (B,4)
                is_target = is_valid[t].unsqueeze(0)  # (B,)
                loss_t, sub = compute_sot_loss(out, gt_box_t, is_target, prototype)
                total_loss = total_loss + loss_t
                for k in metrics_acc:
                    metrics_acc[k] += sub[k]

            total_loss = total_loss / len(outputs)
            total_loss.backward()
            optimizer.step()

            epoch_loss += total_loss.item()

            if step % 10 == 0:
                print(f"Epoch[{epoch}] Step[{step}] Loss={total_loss.item():.4f} cls={metrics_acc['cls']:.4f}")

        t1 = time.time()
        print(f"Epoch {epoch} finished. AvgLoss={(epoch_loss/len(loader)):.4f} Time={(t1-t0):.1f}s")

        # save checkpoint
        ckpt = {"epoch": epoch, "state_dict": model.state_dict(), "optimizer": optimizer.state_dict()}
        torch.save(ckpt, os.path.join(args.out_dir, f"sot_epoch_{epoch}.pth"))

    print("Training completed.")


if __name__ == "__main__":
    main()
