# SOT Adaptation of MOTIP - Quick Start

Files provided:
- models/motip_sot.py
- data/sot_dataset.py
- utils/box.py
- train_sot.py
- infer_sot.py
- eval_sot.py
- configs/sot_config_example.yaml

Steps to run (example):

1. Prepare dataset in MOT-like format (seq folders with img/ and gt/gt.txt).
   For LaSOT / GOT-10k / TrackingNet, use the conversion scripts provided earlier.

2. Provide real backbone and DETR modules.
   In train_sot.py and infer_sot.py replace placeholders:
      backbone = <your_backbone>
      detr = <your_detr_wrapper>
   Your detr wrapper should return a tensor or tuple where the last decoder layer
   output can be used as an embedding with shape (L, B, C) or (B, C).

3. Train:
   python train_sot.py --data-root /path/to/dataset --out-dir ./sot_ckpt --epochs 20 --window 8

4. Inference:
   python infer_sot.py --video_path ./videos/seq1.mp4 --init_bbox 100,200,60,80 --out_dir ./results

5. Evaluation:
   python eval_sot.py --gt ./path/to/gt.txt --pred ./results/result.txt

Notes:
- All comments and code are English-only.
- The code is a prototype; adapt the DETR/backbone API to your project.
- For production: add multi-GPU training, mixed precision, and optimized dataloaders.
