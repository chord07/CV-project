# eval_sot.py
# Evaluate SOT results with standard OTB-style metrics: Precision and Success(AUC).
# This is a simplified evaluator suitable for per-video evaluation.
# Precision: percentage of frames where center distance <= threshold (e.g., 20 px)
# Success: AUC of IoU curve across thresholds [0,1]

import numpy as np
from utils.box import xywh_to_xyxy, iou
import matplotlib.pyplot as plt
import argparse
import os

def load_gt(gt_path):
    """
    Load ground truth for a sequence expected in simple txt format:
    each line: frame_idx, x, y, w, h (or MOT-like: frame,id,x,y,w,h,...)
    We return a list of boxes in xywh aligned by frame starting at 1.
    """
    gt = {}
    with open(gt_path, "r") as f:
        for line in f:
            parts = line.strip().split(",")
            if len(parts) < 6:
                continue
            frame = int(parts[0])
            x = float(parts[2])
            y = float(parts[3])
            w = float(parts[4])
            h = float(parts[5])
            gt[frame] = [x, y, w, h]
    # Convert to ordered list
    max_frame = max(gt.keys())
    out = []
    for i in range(1, max_frame + 1):
        out.append(gt.get(i, [0, 0, 0, 0]))
    return out

def load_pred(pred_path):
    """
    Load predicted txt in format:
    frame_idx,x,y,w,h,score  (one line per frame)
    """
    preds = {}
    with open(pred_path, "r") as f:
        for line in f:
            parts = line.strip().split(",")
            if len(parts) < 5:
                continue
            frame = int(parts[0])
            x = float(parts[1])
            y = float(parts[2])
            w = float(parts[3])
            h = float(parts[4])
            preds[frame] = [x, y, w, h]
    max_frame = max(preds.keys())
    out = []
    for i in range(1, max_frame + 1):
        out.append(preds.get(i, [0, 0, 0, 0]))
    return out

def compute_precision_success(gt_boxes, pred_boxes, dist_threshold=20):
    """
    gt_boxes, pred_boxes: list of [x,y,w,h]
    Return:
        precision at threshold (center distance <= threshold)
        success_curve (IoU) and AUC
    """
    assert len(gt_boxes) == len(pred_boxes)
    N = len(gt_boxes)
    centers_dist = []
    ious = []
    for g, p in zip(gt_boxes, pred_boxes):
        gx = g[0] + g[2] / 2.0
        gy = g[1] + g[3] / 2.0
        px = p[0] + p[2] / 2.0
        py = p[1] + p[3] / 2.0
        dist = np.sqrt((gx - px) ** 2 + (gy - py) ** 2)
        centers_dist.append(dist)

        gxy = xywh_to_xyxy(np.array(g))
        pxy = xywh_to_xyxy(np.array(p))
        iou_val = iou(gxy, pxy)
        if isinstance(iou_val, np.ndarray):
            iou_val = float(iou_val)
        ious.append(iou_val)

    # precision
    prec = sum([1 for d in centers_dist if d <= dist_threshold]) / float(N)

    # success curve: fraction of frames with IoU >= t for t in [0,1]
    thresholds = np.linspace(0.0, 1.0, 101)
    success = []
    for t in thresholds:
        success.append(sum([1 for x in ious if x >= t]) / float(N))
    # AUC approximate
    auc = np.trapz(success, thresholds) / (thresholds[-1] - thresholds[0])
    return prec, thresholds, success, auc

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gt", required=True)
    parser.add_argument("--pred", required=True)
    args = parser.parse_args()

    gt = load_gt(args.gt)
    pred = load_pred(args.pred)

    prec, thresholds, success, auc = compute_precision_success(gt, pred)
    print(f"Precision(@20px) = {prec:.4f}  SuccessAUC = {auc:.4f}")

    # Optionally plot success
    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(thresholds, success)
    plt.title(f"Success Curve (AUC={auc:.4f})")
    plt.xlabel("IoU threshold")
    plt.ylabel("Success rate")
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()
