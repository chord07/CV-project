# utils/box.py
# Basic box utilities used by training/eval

import numpy as np
import torch


def xywh_to_xyxy(box):
    """
    Convert box from (x, y, w, h) to (x1, y1, x2, y2)
    Accepts tensors or numpy arrays.
    """
    if isinstance(box, torch.Tensor):
        x, y, w, h = box.unbind(-1)
        x1 = x
        y1 = y
        x2 = x + w
        y2 = y + h
        return torch.stack([x1, y1, x2, y2], dim=-1)
    else:
        x, y, w, h = box
        return [x, y, x + w, y + h]


def xyxy_to_xywh(box):
    if isinstance(box, torch.Tensor):
        x1, y1, x2, y2 = box.unbind(-1)
        w = x2 - x1
        h = y2 - y1
        return torch.stack([x1, y1, w, h], dim=-1)
    else:
        x1, y1, x2, y2 = box
        return [x1, y1, x2 - x1, y2 - y1]


def iou(box_a, box_b, eps=1e-6):
    """
    Compute IoU between two boxes or arrays of boxes.
    box in xyxy format.
    """
    if isinstance(box_a, torch.Tensor):
        # supports broadcasting
        xa1, ya1, xa2, ya2 = box_a.unbind(-1)
        xb1, yb1, xb2, yb2 = box_b.unbind(-1)

        inter_x1 = torch.max(xa1, xb1)
        inter_y1 = torch.max(ya1, yb1)
        inter_x2 = torch.min(xa2, xb2)
        inter_y2 = torch.min(ya2, yb2)

        inter_w = (inter_x2 - inter_x1).clamp(min=0)
        inter_h = (inter_y2 - inter_y1).clamp(min=0)
        inter = inter_w * inter_h

        area_a = (xa2 - xa1).clamp(min=0) * (ya2 - ya1).clamp(min=0)
        area_b = (xb2 - xb1).clamp(min=0) * (yb2 - yb1).clamp(min=0)
        union = area_a + area_b - inter + eps
        return inter / union
    else:
        # numpy
        xa1, ya1, xa2, ya2 = box_a
        xb1, yb1, xb2, yb2 = box_b
        inter_x1 = max(xa1, xb1)
        inter_y1 = max(ya1, yb1)
        inter_x2 = min(xa2, xb2)
        inter_y2 = min(ya2, yb2)
        inter_w = max(0.0, inter_x2 - inter_x1)
        inter_h = max(0.0, inter_y2 - inter_y1)
        inter = inter_w * inter_h
        area_a = max(0.0, xa2 - xa1) * max(0.0, ya2 - ya1)
        area_b = max(0.0, xb2 - xb1) * max(0.0, yb2 - yb1)
        union = area_a + area_b - inter + eps
        return inter / union
