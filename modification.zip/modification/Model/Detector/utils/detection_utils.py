# utils/detection_utils.py
# Small helpers: box conversions, normalization, and nms wrapper.

import torch
import numpy as np

def xywh_to_cxcywh(boxes):
    """
    boxes: Tensor or ndarray (N,4) x,y,w,h -> cx,cy,w,h
    """
    if isinstance(boxes, torch.Tensor):
        x, y, w, h = boxes.unbind(-1)
        cx = x + w / 2.0
        cy = y + h / 2.0
        return torch.stack([cx, cy, w, h], dim=-1)
    else:
        boxes = np.array(boxes)
        x, y, w, h = boxes[:,0], boxes[:,1], boxes[:,2], boxes[:,3]
        cx = x + w / 2.0
        cy = y + h / 2.0
        return np.stack([cx, cy, w, h], axis=1)


def cxcywh_to_xyxy(boxes):
    """
    cx,cy,w,h -> x1,y1,x2,y2
    Accepts torch or numpy
    """
    if isinstance(boxes, torch.Tensor):
        cx, cy, w, h = boxes.unbind(-1)
        x1 = cx - w/2.0
        y1 = cy - h/2.0
        x2 = cx + w/2.0
        y2 = cy + h/2.0
        return torch.stack([x1, y1, x2, y2], dim=-1)
    else:
        boxes = np.array(boxes)
        cx, cy, w, h = boxes[:,0], boxes[:,1], boxes[:,2], boxes[:,3]
        x1 = cx - w/2.0
        y1 = cy - h/2.0
        x2 = cx + w/2.0
        y2 = cy + h/2.0
        return np.stack([x1, y1, x2, y2], axis=1)


def normalize_boxes_by_size(boxes_xywh, img_w, img_h):
    """
    Normalize xywh pixel boxes to cxcywh in [0,1]
    """
    boxes = xywh_to_cxcywh(boxes_xywh)
    boxes[:, 0] = boxes[:, 0] / img_w
    boxes[:, 1] = boxes[:, 1] / img_h
    boxes[:, 2] = boxes[:, 2] / img_w
    boxes[:, 3] = boxes[:, 3] / img_h
    return boxes
