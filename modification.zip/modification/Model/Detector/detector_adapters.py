# detector_adapters.py
# Detector adapters for MOTIP: YOLOv8Adapter and DINOAdapter.
# Each adapter exposes a uniform API:
#   adapter.predict(images) -> list(dict) for each input image:
#       {'boxes': Tensor[num_det,4] (x,y,w,h),
#        'scores': Tensor[num_det],
#        'labels': Tensor[num_det] (optional),
#        'embeddings': Tensor[num_det, embed_dim] }
#
# Embeddings are projected to a user-chosen d_model using adapter.get_projection()
# or adapter.project(embeddings) helper.

import os
from typing import List, Dict, Optional, Tuple
import torch
import torch.nn as nn
import torchvision.transforms as T
import numpy as np
import cv2

# Optional dependencies:
try:
    from ultralytics import YOLO  # ultralytics YOLOv8
    ULTRALYTICS_AVAILABLE = True
except Exception:
    ULTRALYTICS_AVAILABLE = False

try:
    import timm
    TIMM_AVAILABLE = True
except Exception:
    TIMM_AVAILABLE = False


# ----------------------------
# Utility: crop patches & embed
# ----------------------------
def crop_and_resize(img: np.ndarray, box: Tuple[float, float, float, float], out_size=(128, 128)):
    """
    Crop box from image and resize to out_size.
    Box format: x, y, w, h (pixel coordinates).
    """
    h, w, _ = img.shape
    x, y, bw, bh = box
    x1 = int(round(x))
    y1 = int(round(y))
    x2 = int(round(x + bw))
    y2 = int(round(y + bh))
    # clip
    x1 = max(0, min(x1, w-1))
    x2 = max(0, min(x2, w))
    y1 = max(0, min(y1, h-1))
    y2 = max(0, min(y2, h))
    if x2 <= x1 or y2 <= y1:
        # invalid -> return zeros
        return np.zeros((out_size[1], out_size[0], 3), dtype=np.uint8)
    patch = img[y1:y2, x1:x2, :]
    patch = cv2.resize(patch, out_size)
    return patch


# ----------------------------
# YOLOv8 adapter
# ----------------------------
class YOLOv8Adapter:
    """
    Adapter around Ultralytics YOLOv8 detector.
    - Detects boxes + scores + labels
    - Generates appearance embeddings per detection by cropping and running an embedding backbone (ResNet)
    - Projects embeddings to d_model using a linear projection (optional)
    """

    def __init__(self, model_path: Optional[str] = None, device='cuda', embed_backbone='resnet50',
                 embed_dim=256, proj_dim=256, crop_size=(128, 128)):
        """
        model_path: path to yolov8 weights (if None, uses 'yolov8n.pt' default from ultralytics)
        embed_backbone: timm backbone name or 'resnet50' from torchvision
        embed_dim: embedding dim produced by embedding backbone
        proj_dim: final projection dim to match MOTIP d_model
        crop_size: cropping size for embedding extraction
        """
        if not ULTRALYTICS_AVAILABLE:
            raise ImportError("Ultralytics YOLOv8 (ultralytics) not installed. pip install ultralytics")

        self.device = device
        self.model = YOLO(model_path or "yolov8n.pt")  # loads ultralytics YOLO model
        # ensure model is on correct device for inference calls
        self.model.to(self.device)

        # build appearance embedder
        if TIMM_AVAILABLE:
            self.embed_net = timm.create_model(embed_backbone, pretrained=True, num_classes=0, global_pool='avg')
            embed_out_dim = self.embed_net.num_features
        else:
            # fallback to torchvision resnet50 without final fc
            import torchvision.models as models
            res = models.resnet50(pretrained=True)
            modules = list(res.children())[:-1]  # remove fc
            self.embed_net = nn.Sequential(*modules)
            embed_out_dim = 2048

        self.embed_net.eval().to(self.device)
        self.embed_dim = embed_out_dim
        self.crop_size = crop_size

        # projection to final d_model
        self.proj = nn.Linear(self.embed_dim, proj_dim).to(self.device)
        self.proj_dim = proj_dim

        # transforms for patch -> tensor
        self.to_tensor = T.Compose([
            T.ToPILImage(),
            T.Resize(self.crop_size),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]),
        ])

    def image_to_numpy(self, image: torch.Tensor) -> np.ndarray:
        """
        Convert a torch tensor image or PIL to numpy (H,W,3) uint8
        Accepts: HxWxC numpy or torch tensor CxHxW or HxWxC
        """
        if isinstance(image, torch.Tensor):
            img = image.detach().cpu().numpy()
            if img.ndim == 3 and img.shape[0] in (1, 3):
                img = np.transpose(img, (1, 2, 0))
            img = (img * 255.0).astype(np.uint8)
            return img
        elif isinstance(image, np.ndarray):
            return image
        else:
            # assume PIL
            return np.asarray(image)

    def detect(self, images: List[np.ndarray], conf=0.25, iou=0.45):
        """
        Run YOLO detection on a list of numpy images.
        Returns:
            detections: list (len = batch) of dicts: {'boxes': Tensor[n,4], 'scores': Tensor[n], 'labels': Tensor[n]}
            boxes format: x, y, w, h (pixels)
        """
        results = self.model.predict(source=images, conf=conf, iou=iou, device=self.device, verbose=False)
        outputs = []
        for res in results:
            # res.boxes.xyxyn or xywhn etc. For simplicity we extract xyxy and convert to xywh in pixels
            boxes = res.boxes.xyxy.cpu().numpy()  # (n,4): x1,y1,x2,y2 in pixels
            scores = res.boxes.conf.cpu().numpy()
            labels = res.boxes.cls.cpu().numpy().astype(np.int32)
            # convert to xywh
            xywh = []
            for (x1, y1, x2, y2) in boxes:
                xywh.append([float(x1), float(y1), float(x2 - x1), float(y2 - y1)])
            outputs.append({
                'boxes': np.array(xywh, dtype=np.float32),
                'scores': np.array(scores, dtype=np.float32),
                'labels': np.array(labels, dtype=np.int32)
            })
        return outputs

    def embed_patches(self, img_np: np.ndarray, boxes: np.ndarray, batch_size=32):
        """
        Given image (H,W,3) and boxes (n,4 x,y,w,h), return embeddings (n, embed_dim) from embed_net.
        This crops patches and runs embed_net on them in batches.
        """
        patches = []
        for b in boxes:
            p = crop_and_resize(img_np, b, out_size=self.crop_size)
            patches.append(p)

        # run in batches
        embeddings = []
        for i in range(0, len(patches), batch_size):
            batch = patches[i:i+batch_size]
            # convert to tensor
            tens = torch.stack([self.to_tensor(b) for b in batch], dim=0).to(self.device)
            with torch.no_grad():
                out = self.embed_net(tens)
                if isinstance(out, torch.Tensor) and out.dim() == 4:
                    # if torchvision resnet without flatten, output is (B, C, 1, 1)
                    out = out.view(out.size(0), -1)
                out = out.detach()
                embeddings.append(out.cpu())
        if len(embeddings) > 0:
            embeddings = torch.cat(embeddings, dim=0)
        else:
            embeddings = torch.zeros((0, self.embed_dim))
        return embeddings  # CPU tensor

    def predict(self, images: List, conf=0.25, iou=0.45, device='cuda'):
        """
        Full pipeline: detect -> crop -> embed -> project.
        Input images: list of numpy arrays (H,W,3) or PIL or torch tensors.
        Returns list of dicts: {'boxes','scores','labels','embeddings'}
        """
        # convert to numpy if needed
        np_images = [self.image_to_numpy(im) for im in images]
        dets = self.detect(np_images, conf=conf, iou=iou)
        outputs = []
        for img_np, d in zip(np_images, dets):
            boxes = d['boxes']
            scores = d['scores']
            labels = d['labels']
            if boxes.shape[0] == 0:
                outputs.append({'boxes': torch.zeros((0,4)), 'scores': torch.zeros((0,)), 'labels': torch.zeros((0,), dtype=torch.int64), 'embeddings': torch.zeros((0, self.proj.in_features))})
                continue
            emb = self.embed_patches(img_np, boxes)  # CPU tensor (n, embed_dim)
            # project to proj_dim
            emb = emb.to(self.proj.weight.device)
            proj_emb = self.proj(emb)  # (n, proj_dim)
            # L2 normalize
            proj_emb = torch.nn.functional.normalize(proj_emb, p=2, dim=1)
            outputs.append({
                'boxes': torch.tensor(boxes, dtype=torch.float32),
                'scores': torch.tensor(scores, dtype=torch.float32),
                'labels': torch.tensor(labels, dtype=torch.int64),
                'embeddings': proj_emb  # Tensor on proj device (usually cuda)
            })
        return outputs

    def get_projection(self):
        return self.proj


# ----------------------------
# DINO / DETR adapter
# ----------------------------
class DINOAdapter:
    """
    Adapter for a DETR-like model that already produces per-query embeddings (hs).
    This wrapper expects the model forward to return a dict with keys:
        'pred_logits', 'pred_boxes', and optionally 'outputs' (hs last layer)
    If the model does not return embeddings, this wrapper will produce embeddings by
    extracting the region features (crop & embed) — fallback mode.
    """

    def __init__(self, detr_model: nn.Module, device='cuda', proj_dim=256, fallback_embed_net=None):
        """
        detr_model: a PyTorch DETR-like model (DeformableDETR / DINO DETR)
        proj_dim: final projection dim to d_model
        fallback_embed_net: optional embedding network to produce embeddings if detr doesn't return hs
        """
        self.model = detr_model.to(device)
        self.device = device
        self.model.eval()
        self.proj = nn.Linear(self._get_model_embed_dim(), proj_dim).to(device)
        self.proj_dim = proj_dim
        # fallback embedding net (if needed)
        self.fallback = fallback_embed_net
        if self.fallback is not None:
            self.fallback = self.fallback.to(device)
            self.fallback.eval()

    def _get_model_embed_dim(self):
        # try to infer hidden dim from transformer or model outputs
        # Many DETR-like models expose transformer.d_model or hs shape
        if hasattr(self.model, 'transformer') and hasattr(self.model.transformer, 'd_model'):
            return self.model.transformer.d_model
        # fallback
        # try to run a dummy forward? leave default
        return 256

    @torch.no_grad()
    def predict(self, images: List[torch.Tensor], threshold=0.05):
        """
        images: list of tensors (C,H,W) or nested tensors depending on model.
        Returns:
            list of dicts: {'boxes': Tensor[n,4], 'scores': Tensor[n], 'labels': Tensor[n], 'embeddings': Tensor[n,proj_dim]}
        """
        outputs = []
        # move model to eval, device ensured
        for img in images:
            # if img is numpy, convert to tensor
            if isinstance(img, np.ndarray):
                img_tensor = torch.tensor(img).permute(2,0,1).float().to(self.device) / 255.0
            else:
                img_tensor = img.to(self.device)

            # model forward: adapt to the model API (this is the place you might need to change)
            res = self.model([img_tensor])  # many DETR wrappers accept list of tensors and return dict

            # expecting outputs keys: 'pred_logits', 'pred_boxes', and optionally 'outputs' (hs)
            pred_logits = res.get('pred_logits', None)
            pred_boxes = res.get('pred_boxes', None)
            hs = res.get('outputs', None)  # hs: (num_queries, B, C) or (B, num_queries, C)

            # process boxes & scores
            if pred_boxes is None or pred_logits is None:
                # fallback: no detection outputs — skip
                outputs.append({'boxes': torch.zeros((0,4)), 'scores': torch.zeros((0,)), 'labels': torch.zeros((0,), dtype=torch.int64), 'embeddings': torch.zeros((0,self.proj_dim))})
                continue

            # get scores & labels from pred_logits (assume sigmoid multi-label or softmax)
            # if shape [B, Q, num_classes]
            if pred_logits.dim() == 3:
                # choose max over classes
                probs = pred_logits.sigmoid() if pred_logits.min() < 0 else pred_logits.softmax(-1)
                # For simplicity, take max class probability as score and argmax label
                scores, labels = torch.max(probs, dim=-1)  # (B, Q)
                scores = scores[0]  # (Q,)
                labels = labels[0].long()
            else:
                # unusual -> fallback
                scores = torch.zeros(pred_boxes.shape[1], device=self.device)
                labels = torch.zeros(pred_boxes.shape[1], dtype=torch.int64, device=self.device)

            # boxes assumed normalized cxcywh [0,1], convert to pixels later in MOTIP pipeline if needed
            boxes = pred_boxes[0]  # (Q, 4)

            # embeddings: if hs provided, attempt to get per-query embedding
            if hs is not None:
                # hs may be (L, B, Q, C) or (L, B, C) - handle common cases
                if hs.dim() == 4:
                    cur_hs = hs[-1, 0]  # (Q, C)
                elif hs.dim() == 3:
                    cur_hs = hs[-1]  # (B, C) or (Q, C) depending on model - assume (Q, C)
                else:
                    cur_hs = hs
                emb = cur_hs  # (Q, C)
                emb = emb.to(self.proj.weight.device)
                emb = self.proj(emb)  # (Q, proj_dim)
                emb = torch.nn.functional.normalize(emb, p=2, dim=1)
            else:
                # fallback: crop & embed using fallback embed net (if given)
                if self.fallback is None:
                    emb = torch.zeros((boxes.shape[0], self.proj_dim), device=self.device)
                else:
                    # TODO: implement cropping from original image and pass through fallback to get features
                    emb = torch.zeros((boxes.shape[0], self.proj_dim), device=self.device)

            # filter by threshold
            keep = scores >= threshold
            boxes_k = boxes[keep].detach().cpu()
            scores_k = scores[keep].detach().cpu()
            labels_k = labels[keep].detach().cpu()
            emb_k = emb[keep].detach().cpu()

            outputs.append({
                'boxes': boxes_k,  # normalized boxes in many DETR -> convert later
                'scores': scores_k,
                'labels': labels_k,
                'embeddings': emb_k,
            })
        return outputs

    def get_projection(self):
        return self.proj
