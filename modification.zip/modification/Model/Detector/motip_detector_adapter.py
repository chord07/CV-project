# motip_detector_adapter.py
# Integration helper to plug detector adapters into MOTIP.
# Provides function `adapter_infer_to_motip_outputs` to convert an adapter output
# to the data structures MOTIP's RuntimeTracker expects.

import torch
import numpy as np
from detector_adapters import YOLOv8Adapter, DINOAdapter
from utils.detection_utils import xywh_to_cxcywh, normalize_boxes_by_size

def adapter_infer_to_motip_outputs(adapter_outputs, image_sizes, to_device='cpu'):
    """
    Convert adapter outputs (list per image) into MOTIP/DETR-like output dict:
      - 'pred_logits' (B, Q, num_classes) optional
      - 'pred_boxes' (B, Q, 4) normalized (cx,cy,w,h) in [0,1]
      - 'outputs' (for embeddings) (Q, B, C) or (B, Q, C)
    This helper is intentionally generic; MOTIP expects outputs['outputs']=hs[-1]
    """
    batch_size = len(adapter_outputs)
    # For simplicity we produce:
    # pred_boxes: pad to max_q per batch with zeros
    max_q = max([out['boxes'].shape[0] for out in adapter_outputs])
    pred_boxes = torch.zeros((batch_size, max_q, 4), dtype=torch.float32)
    pred_scores = torch.zeros((batch_size, max_q), dtype=torch.float32)
    pred_labels = torch.zeros((batch_size, max_q), dtype=torch.int64)
    embeddings = []

    for i, out in enumerate(adapter_outputs):
        boxes = out['boxes']  # (n,4) xywh (pixels)
        scores = out['scores']
        labels = out.get('labels', torch.zeros(scores.shape, dtype=torch.int64))
        emb = out['embeddings']  # (n, C)

        if boxes.shape[0] == 0:
            continue
        # normalize boxes by respective image size to cxcywh in [0,1]
        W, H = image_sizes[i]
        boxes_cxcywh = xywh_to_cxcywh(boxes)  # still pixel coords
        boxes_norm = boxes_cxcywh.clone()
        boxes_norm[:, 0] = boxes_cxcywh[:, 0] / W
        boxes_norm[:, 1] = boxes_cxcywh[:, 1] / H
        boxes_norm[:, 2] = boxes_cxcywh[:, 2] / W
        boxes_norm[:, 3] = boxes_cxcywh[:, 3] / H

        q = boxes.shape[0]
        pred_boxes[i, :q] = boxes_norm
        pred_scores[i, :q] = scores
        pred_labels[i, :q] = labels
        # embeddings: pad to max_q as well
        # we'll collect embeddings per image and then stack into (batch, q, C)
        embeddings.append(emb)

    # build embeddings array (B, max_q, C) padded with zeros
    if len(embeddings) == 0:
        embeddings_tensor = torch.zeros((batch_size, max_q, adapter_outputs[0]['embeddings'].shape[1] if batch_size>0 else 256))
    else:
        C = embeddings[0].shape[1]
        emb_tensor = torch.zeros((batch_size, max_q, C))
        for i, out in enumerate(adapter_outputs):
            n = out['embeddings'].shape[0]
            if n > 0:
                emb_tensor[i, :n] = out['embeddings']
        embeddings_tensor = emb_tensor

    # For compatibility with MOTIP/DETR, place embeddings in outputs dict
    # Some parts of MOTIP expect 'outputs' = hs[-1] shape (Q, B, C) or (B, Q, C)
    outputs = {
        'pred_boxes': pred_boxes.to(to_device),
        'pred_scores': pred_scores.to(to_device),
        'pred_labels': pred_labels.to(to_device),
        'outputs': embeddings_tensor.to(to_device)  # (B, Q, C)
    }
    return outputs
