import random
import torch
import numpy as np
import cv2


# ==========================
#  Utility Functions
# ==========================

def apply_box_occlusion(image, bbox, fill_value=0):
    """Randomly occlude a region inside the bbox."""
    x, y, w, h = bbox
    x1 = int(x + random.uniform(0, w * 0.5))
    y1 = int(y + random.uniform(0, h * 0.5))
    w_occ = int(w * random.uniform(0.3, 0.7))
    h_occ = int(h * random.uniform(0.3, 0.7))
    x2 = min(x + w, x1 + w_occ)
    y2 = min(y + h, y1 + h_occ)
    image[y1:y2, x1:x2] = fill_value
    return image


def random_mask(image):
    """Apply a random square mask to simulate background occlusion."""
    h, w = image.shape[:2]
    sz = random.randint(int(0.1 * min(h, w)), int(0.25 * min(h, w)))
    x = random.randint(0, w - sz)
    y = random.randint(0, h - sz)
    image[y:y + sz, x:x + sz] = 0
    return image


# ==========================
#  Occlusion Augmentor
# ==========================

class OcclusionAugmentor:
    """Simulate partial/full occlusion."""

    def __init__(self, box_occ_prob=0.3, cutout_prob=0.2, full_occ_prob=0.1):
        self.box_occ_prob = box_occ_prob
        self.cutout_prob = cutout_prob
        self.full_occ_prob = full_occ_prob

    def __call__(self, image, bbox, embedding):
        """Apply occlusion augmentation."""
        x, y, w, h = bbox.copy()

        # Full occlusion
        if random.random() < self.full_occ_prob:
            embedding[:] = 0
            return image, np.array([0, 0, 0, 0]), embedding

        # Box occlusion
        if random.random() < self.box_occ_prob:
            image = apply_box_occlusion(image, bbox, fill_value=0)

        # CutOut mask
        if random.random() < self.cutout_prob:
            image = random_mask(image)

        return image, bbox, embedding


# ==========================
#  ID Noise Augmentor
# ==========================

class IDNoiseAugmentor:
    """Inject ID noise or wrong identity to simulate ID switch."""

    def __init__(self, id_switch_prob=0.2, wrong_id_prob=0.2, max_ids=500):
        self.id_switch_prob = id_switch_prob
        self.wrong_id_prob = wrong_id_prob
        self.max_ids = max_ids

    def __call__(self, track_id):
        """Apply ID corruption."""
        # ID flip
        if random.random() < self.id_switch_prob:
            return track_id + 1

        # Wrong ID
        if random.random() < self.wrong_id_prob:
            return random.randint(1, self.max_ids)

        return track_id


# ==========================
#  Tracklet Augmentor
# ==========================

class TrackletAugmentor:
    """Simulate frame drop, jitter, missing detection."""

    def __init__(self, drop_prob=0.1, jitter_prob=0.2, max_jitter=8):
        self.drop_prob = drop_prob
        self.jitter_prob = jitter_prob
        self.max_jitter = max_jitter

    def jitter_bbox(self, bbox):
        x, y, w, h = bbox
        x += random.randint(-self.max_jitter, self.max_jitter)
        y += random.randint(-self.max_jitter, self.max_jitter)
        return np.array([max(0, x), max(0, y), w, h])

    def __call__(self, bbox, embedding):
        # Drop Frame
        if random.random() < self.drop_prob:
            return np.array([0, 0, 0, 0]), np.zeros_like(embedding)

        # Jitter
        if random.random() < self.jitter_prob:
            bbox = self.jitter_bbox(bbox)

        return bbox, embedding


# ==========================
#  Combined Augmentor
# ==========================

class MOTIPAugmentor:
    """
    Combine all augmentation strategies.
    Use inside your training dataloader or training loop.
    """

    def __init__(self):
        self.occ_aug = OcclusionAugmentor()
        self.id_aug = IDNoiseAugmentor()
        self.track_aug = TrackletAugmentor()

    def __call__(self, image, bbox, track_id, embedding):
        # Occlusion
        image, bbox, embedding = self.occ_aug(image, bbox, embedding)

        # Tracklet-level augment
        bbox, embedding = self.track_aug(bbox, embedding)

        # ID noise
        track_id = self.id_aug(track_id)

        return image, bbox, track_id, embedding


# ==========================
#  Example Usage in Training
# ==========================

def apply_augmentation_to_sample(sample, augmentor):
    """
    sample: dict from dataset
        - 'image': numpy array
        - 'bbox': np.array
        - 'track_id': int
        - 'embedding': np.array
    """
    img = sample["image"]
    bbox = sample["bbox"]
    tid = sample["track_id"]
    emb = sample["embedding"]

    img, bbox, tid, emb = augmentor(img, bbox, tid, emb)

    sample["image"] = img
    sample["bbox"] = bbox
    sample["track_id"] = tid
    sample["embedding"] = emb

    return sample


if __name__ == "__main__":
    augmentor = MOTIPAugmentor()

    # Fake example
    sample = {
        "image": np.zeros((480, 640, 3), dtype=np.uint8),
        "bbox": np.array([100, 200, 80, 160]),
        "track_id": 5,
        "embedding": np.random.randn(256),
    }

    new_sample = apply_augmentation_to_sample(sample, augmentor)
    print("Done:", new_sample)
