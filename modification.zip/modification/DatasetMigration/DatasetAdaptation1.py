"""
Convert UA-DETRAC to MOTChallenge format.
Output structure:
  UA-DETRAC/
      train/
         MVI_XXXXXX/img1/
         MVI_XXXXXX/gt/gt.txt
      train_seqmap.txt
"""

import os
import json
import cv2
import xml.etree.ElementTree as ET

def convert_uadetrac(det_root, out_root):
    """
    det_root: original UA-DETRAC root
    out_root: target path with MOTChallenge format
    """

    seqmap = []

    for seq in sorted(os.listdir(det_root)):
        ann_path = os.path.join(det_root, seq, "gt.xml")
        img_dir = os.path.join(det_root, seq, "img")
        if not os.path.exists(ann_path):
            continue

        out_seq = os.path.join(out_root, seq)
        os.makedirs(os.path.join(out_seq, "img1"), exist_ok=True)
        os.makedirs(os.path.join(out_seq, "gt"), exist_ok=True)

        # copy images
        frames = sorted(os.listdir(img_dir))
        for i, f in enumerate(frames, start=1):
            img = cv2.imread(os.path.join(img_dir, f))
            cv2.imwrite(os.path.join(out_seq, "img1", f"{i:06d}.jpg"), img)

        # parse xml
        tree = ET.parse(ann_path)
        root = tree.getroot()

        # write gt.txt
        gt_file = open(os.path.join(out_seq, "gt", "gt.txt"), "w")

        for frame_ann in root.findall("frame"):
            frame_id = int(frame_ann.attrib["num"])
            for t in frame_ann.find("target_list").findall("target"):
                tid = int(t.attrib["id"])
                box = t.find("box").attrib
                x, y, w, h = float(box["left"]), float(box["top"]), float(box["width"]), float(box["height"])
                gt_file.write(f"{frame_id},{tid},{x},{y},{w},{h},1,1,1,1\n")

        gt_file.close()
        seqmap.append(seq)

    with open(os.path.join(out_root, "train_seqmap.txt"), "w") as f:
        for s in seqmap:
            f.write(s + "\n")

