"""
Run TrackEval for any MOTChallenge-format dataset
"""

import subprocess
import os
import argparse

def run_eval(gt_dir, tracker_dir, seqmap_file):
    cmd = [
        "python", "TrackEval/scripts/run_mot_challenge.py",
        "--GT_FOLDER", gt_dir,
        "--TRACKERS_FOLDER", tracker_dir,
        "--SEQMAP_FILE", seqmap_file,
        "--SKIP_SPLIT_FOL", "True",
        "--METRICS", "HOTA", "CLEAR", "Identity",
        "--USE_PARALLEL", "True",
        "--NUM_PARALLEL_CORES", "8"
    ]
    subprocess.run(cmd)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gt", required=True)
    parser.add_argument("--tracker", required=True)
    parser.add_argument("--seqmap", required=True)
    a = parser.parse_args()

    run_eval(a.gt, a.tracker, a.seqmap)
