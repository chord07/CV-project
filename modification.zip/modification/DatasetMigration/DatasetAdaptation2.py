"""
CityFlow to MOTChallenge conversion.
CityFlow gt is typically JSON or txt.
"""

import os
import json
import cv2

def convert_cityflow(raw_root, out_root):
    os.makedirs(out_root, exist_ok=True)
    seqmap = []

    for seq in sorted(os.listdir(raw_root)):
        if not seq.startswith("S"):
            continue

        img_dir = os.path.join(raw_root, seq, "img1")
        ann_path = os.path.join(raw_root, seq, "gt", "gt.json")

        out_seq = os.path.join(out_root, seq)
        os.makedirs(out_seq, exist_ok=True)
        os.makedirs(os.path.join(out_seq, "img1"), exist_ok=True)
        os.makedirs(os.path.join(out_seq, "gt"), exist_ok=True)

        # copy imgs
        for i, fname in enumerate(sorted(os.listdir(img_dir)), 1):
            img = cv2.imread(os.path.join(img_dir, fname))
            cv2.imwrite(os.path.join(out_seq, "img1", f"{i:06d}.jpg"), img)

        # parse json
        anns = json.load(open(ann_path))
        gtfile = open(os.path.join(out_seq, "gt", "gt.txt"), "w")

        for f in anns:
            frame = int(f["frame"])
            tid = int(f["id"])
            x, y, w, h = f["bbox"]
            gtfile.write(f"{frame},{tid},{x},{y},{w},{h},1,1,1,1\n")

        gtfile.close()
        seqmap.append(seq)

    with open(os.path.join(out_root, "train_seqmap.txt"), "w") as f:
        f.writelines([s + "\n" for s in seqmap])
