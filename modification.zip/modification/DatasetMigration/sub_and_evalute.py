# Copyright (c) Ruopeng Gao.
# Modified by <your_name> to support UA-DETRAC / CityFlow / MDMT datasets.
# All modifications are marked with:  ### [ADDED] for dataset migration support.

import os
import time
import torch
import subprocess
from accelerate import Accelerator
from accelerate.state import PartialState
from torch.utils.data import DataLoader

from runtime_option import runtime_option
from utils.misc import yaml_to_dict
from configs.util import load_super_config, update_config
from log.logger import Logger
from data.joint_dataset import dataset_classes
from data.seq_dataset import SeqDataset
from models.runtime_tracker import RuntimeTracker
from log.log import Metrics
from models.motip import build as build_motip
from models.misc import load_checkpoint


def submit_and_evaluate(config: dict):
    accelerator = Accelerator()
    state = PartialState()

    mode = config["INFERENCE_MODE"]
    assert mode in ["submit", "evaluate"]
    outputs_dir = config["OUTPUTS_DIR"]
    inference_group = config["INFERENCE_GROUP"]
    inference_dataset = config["INFERENCE_DATASET"]
    inference_split = config["INFERENCE_SPLIT"]
    inference_model = config["INFERENCE_MODEL"]
    model_name = os.path.split(inference_model)[-1][:-4]

    # Build output directory
    outputs_dir = os.path.join(
        outputs_dir, mode, inference_group, inference_dataset, inference_split, model_name
    )
    existed = os.path.exists(outputs_dir)
    accelerator.wait_for_everyone()
    os.makedirs(outputs_dir, exist_ok=True)

    logger = Logger(logdir=str(outputs_dir), use_wandb=False, config=config)
    logger.config(config=config)
    logger.info(
        f"{mode.capitalize()} model={inference_model}, dataset={inference_dataset}, split={inference_split}"
    )

    if existed:
        logger.warning(f"Output dir {outputs_dir} already exists.")
        time.sleep(3)

    model, _ = build_motip(config=config)

    if not config.get("USE_PREVIOUS_CHECKPOINT", False):
        load_checkpoint(model, config["INFERENCE_MODEL"])
    else:
        from models.misc import load_previous_checkpoint
        load_previous_checkpoint(model, config["INFERENCE_MODEL"])

    model = accelerator.prepare(model)

    metrics = submit_and_evaluate_one_model(
        is_evaluate=config["INFERENCE_MODE"] == "evaluate",
        accelerator=accelerator,
        state=state,
        logger=logger,
        model=model,
        data_root=config["DATA_ROOT"],
        dataset=inference_dataset,
        data_split=inference_split,
        outputs_dir=outputs_dir,
        image_max_longer=config["INFERENCE_MAX_LONGER"],
        size_divisibility=config.get("SIZE_DIVISIBILITY", 0),
        use_sigmoid=config.get("USE_FOCAL_LOSS", False),
        assignment_protocol=config.get("ASSIGNMENT_PROTOCOL", "hungarian"),
        miss_tolerance=config["MISS_TOLERANCE"],
        det_thresh=config["DET_THRESH"],
        newborn_thresh=config["NEWBORN_THRESH"],
        id_thresh=config["ID_THRESH"],
        area_thresh=config.get("AREA_THRESH", 0),
        inference_only_detr=config["INFERENCE_ONLY_DETR"] if config["INFERENCE_ONLY_DETR"] is not None else config["ONLY_DETR"],
        dtype=config.get("INFERENCE_DTYPE", "FP32"),
    )

    if metrics is not None:
        metrics.sync()
        logger.metrics(
            log=f"Evaluation for model {inference_model}, dataset {inference_dataset}",
            metrics=metrics, fmt="{global_average:.4f}"
        )


def submit_and_evaluate_one_model(
        is_evaluate: bool,
        accelerator: Accelerator,
        state: PartialState,
        logger: Logger,
        model,
        data_root: str,
        dataset: str,
        data_split: str,
        outputs_dir: str,
        image_max_shorter: int = 800,
        image_max_longer: int = 1536,
        size_divisibility: int = 0,
        use_sigmoid: bool = False,
        assignment_protocol: str = "hungarian",
        miss_tolerance: int = 30,
        det_thresh: float = 0.5,
        newborn_thresh: float = 0.5,
        id_thresh: float = 0.1,
        area_thresh: int = 0,
        inference_only_detr: bool = False,
        dtype: str = "FP32",
):
    # Load joint dataset
    inference_dataset = dataset_classes[dataset](
        data_root=data_root,
        split=data_split,
        load_annotation=False,
    )

    match dtype:
        case "FP32": dtype = torch.float32
        case "FP16": dtype = torch.float16
        case _: raise ValueError(f"Unknown dtype={dtype}")

    seq_names = list(inference_dataset.sequence_infos.keys())
    seq_names.sort()

    # Multi-GPU partitioning:
    if len(seq_names) <= state.process_index:
        inference_dataset.sequence_infos = {seq_names[0]: inference_dataset.sequence_infos[seq_names[0]]}
        inference_dataset.image_paths = {seq_names[0]: inference_dataset.image_paths[seq_names[0]]}
        is_fake = True
    else:
        for i in range(len(seq_names)):
            if i % state.num_processes != state.process_index:
                inference_dataset.sequence_infos.pop(seq_names[i])
                inference_dataset.image_paths.pop(seq_names[i])
        is_fake = False

    # Process each sequence:
    for seq_name in inference_dataset.sequence_infos.keys():
        sequence_dataset = SeqDataset(
            seq_info=inference_dataset.sequence_infos[seq_name],
            image_paths=inference_dataset.image_paths[seq_name],
            max_shorter=image_max_shorter,
            max_longer=image_max_longer,
            size_divisibility=size_divisibility,
            dtype=dtype,
        )

        loader = DataLoader(
            dataset=sequence_dataset,
            batch_size=1, shuffle=False, num_workers=4,
            pin_memory=True,
            collate_fn=lambda x: x[0]
        )

        seq_hw = sequence_dataset.seq_hw()
        tracker = RuntimeTracker(
            model=model,
            sequence_hw=seq_hw,
            use_sigmoid=use_sigmoid,
            assignment_protocol=assignment_protocol,
            miss_tolerance=miss_tolerance,
            det_thresh=det_thresh,
            newborn_thresh=newborn_thresh,
            id_thresh=id_thresh,
            area_thresh=area_thresh,
            only_detr=inference_only_detr,
            dtype=dtype,
        )

        logger.info(f"Submitting {seq_name} ({len(loader)} frames)")

        seq_results, fps = get_results_of_one_sequence(
            runtime_tracker=tracker,
            sequence_loader=loader,
            logger=logger,
        )

        ### [ADDED] universal MOTChallenge-format export
        if dataset in ["DanceTrack", "SportsMOT", "MOT17", "PersonPath22_Inference", "BFT",
                       "UA-DETRAC", "CityFlow", "MDMT"]:
            results_txt = []
            for t in range(len(seq_results)):
                for obj_id, score, category, bbox in zip(
                        seq_results[t]["id"],
                        seq_results[t]["score"],
                        seq_results[t]["category"],
                        seq_results[t]["bbox"]
                ):
                    results_txt.append(
                        f"{t+1},{obj_id.item()},{bbox[0].item()},{bbox[1].item()},"
                        f"{bbox[2].item()},{bbox[3].item()},1,-1,-1,-1\n"
                    )

            if not is_fake:
                out_dir = os.path.join(outputs_dir, "tracker")
                os.makedirs(out_dir, exist_ok=True)
                with open(os.path.join(out_dir, f"{seq_name}.txt"), "w") as f:
                    f.writelines(results_txt)
                logger.success(f"Saved {seq_name}. FPS={fps:.2f}")
        else:
            raise NotImplementedError(f"{dataset} export not supported.")

    # =================== Evaluation ==================
    accelerator.wait_for_everyone()
    if not is_evaluate:
        logger.success("Submit only. Done.")
        return None

    if accelerator.is_main_process:
        logger.info("Start evaluation...")

        ### [ADDED] evaluation support
        if dataset in ["DanceTrack", "SportsMOT", "BFT"] or (dataset == "MOT17" and data_split == "test"):
            gt_dir = os.path.join(data_root, dataset, data_split)
            tracker_dir = os.path.join(outputs_dir, "tracker")
            args = {
                "--SPLIT_TO_EVAL": data_split,
                "--METRICS": ["HOTA", "CLEAR", "Identity"],
                "--GT_FOLDER": gt_dir,
                "--SEQMAP_FILE": os.path.join(data_root, dataset, f"{data_split}_seqmap.txt"),
                "--SKIP_SPLIT_FOL": "True",
                "--TRACKERS_TO_EVAL": "",
                "--TRACKER_SUB_FOLDER": "",
                "--USE_PARALLEL": "True",
                "--NUM_PARALLEL_CORES": "8",
                "--PLOT_CURVES": "False",
                "--TRACKERS_FOLDER": tracker_dir,
            }
            cmd = ["python", "TrackEval/scripts/run_mot_challenge.py"]

        elif dataset in ["UA-DETRAC", "CityFlow", "MDMT"]:
            ### [ADDED] unified evaluation for your datasets
            gt_dir = os.path.join(data_root, dataset, data_split)
            tracker_dir = os.path.join(outputs_dir, "tracker")
            args = {
                "--SPLIT_TO_EVAL": data_split,
                "--METRICS": ["HOTA", "CLEAR", "Identity"],
                "--GT_FOLDER": gt_dir,
                "--SEQMAP_FILE": os.path.join(data_root, dataset, f"{data_split}_seqmap.txt"),
                "--SKIP_SPLIT_FOL": "True",
                "--TRACKERS_TO_EVAL": "",
                "--TRACKER_SUB_FOLDER": "",
                "--USE_PARALLEL": "True",
                "--NUM_PARALLEL_CORES": "8",
                "--PLOT_CURVES": "False",
                "--TRACKERS_FOLDER": tracker_dir,
            }
            cmd = ["python", "TrackEval/scripts/run_mot_challenge.py"]

        else:
            raise NotImplementedError(f"No eval support for dataset={dataset}")

        for k, v in args.items():
            cmd.append(k)
            if isinstance(v, list):
                cmd += v
            else:
                cmd.append(v)

        ret = subprocess.run(cmd)
        if ret.returncode != 0:
            raise RuntimeError("Evaluation failed.")

        logger.success("Evaluation finished.")

    accelerator.wait_for_everyone()

    metrics_path = os.path.join(outputs_dir, "tracker", "pedestrian_summary.txt")
    metrics_dict = get_eval_metrics_dict(metrics_path)
    metrics = Metrics()
    for k, v in metrics_dict.items():
        metrics[k].update(v)
    return metrics


@torch.no_grad()
def get_results_of_one_sequence(logger, runtime_tracker, sequence_loader):
    results = []
    assert len(sequence_loader) > 10
    for t, (image, image_path) in enumerate(sequence_loader):
        if t == 10:
            start = time.time()

        image.tensors = image.tensors.cuda()
        image.mask = image.mask.cuda()
        runtime_tracker.update(image=image)
        results.append(runtime_tracker.get_track_results())

    fps = (len(sequence_loader) - 10) / (time.time() - start)
    return results, fps


def get_eval_metrics_dict(metric_path: str):
    with open(metric_path) as f:
        names = f.readline().strip().split(" ")
        vals = f.readline().strip().split(" ")
    return {k: float(v) for k, v in zip(names, vals)}


if __name__ == "__main__":
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    opt = runtime_option()
    cfg = yaml_to_dict(opt.config_path)

    if opt.super_config_path:
        cfg = load_super_config(cfg, opt.super_config_path)
    else:
        cfg = load_super_config(cfg, cfg["SUPER_CONFIG_PATH"])

    cfg = update_config(cfg, opt)
    submit_and_evaluate(cfg)
