"""
MDMT (VisDrone Multi-Drone MOT) to MOTChallenge format.
"""

import os
import cv2

def convert_mdmt(mdmt_root, out_root):
    os.makedirs(out_root, exist_ok=True)
    seqmap = []

    for seq in sorted(os.listdir(mdmt_root)):
        seq_dir = os.path.join(mdmt_root, seq)
        if not os.path.isdir(seq_dir):
            continue

        img_dir = os.path.join(seq_dir, "img1")
        ann_path = os.path.join(seq_dir, "gt", "gt.txt")

        out_seq = os.path.join(out_root, seq)
        os.makedirs(os.path.join(out_seq, "img1"), exist_ok=True)
        os.makedirs(os.path.join(out_seq, "gt"), exist_ok=True)

        # copy imgs
        for i, f in enumerate(sorted(os.listdir(img_dir)), 1):
            img = cv2.imread(os.path.join(img_dir, f))
            cv2.imwrite(os.path.join(out_seq, "img1", f"{i:06d}.jpg"), img)

        # simply copy gt.txt
        import shutil
        shutil.copy(ann_path, os.path.join(out_seq, "gt", "gt.txt"))

        seqmap.append(seq)

    with open(os.path.join(out_root, "train_seqmap.txt"), "w") as f:
        f.write("\n".join(seqmap))
